<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Blog_model');
    }

    public function index() {
        $data['posts'] = $this->Blog_model->get_posts();
        $this->load->view('blog/index', $data);
    }

    public function details($id) {
        $data['post'] = $this->Blog_model->get_post($id);
        $this->load->view('blog/details', $data);
    }
}
