<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blog Details</title>
</head>
<body>
    <?php if (!empty($post)) : ?>
        <h1><?php echo $post->title; ?></h1>
        <p><?php echo $post->content; ?></p>
        <p>Published on: <?php echo $post->created_at; ?></p>
    <?php else : ?>
        <p>Post not found.</p>
    <?php endif; ?>
</body>
</html>
