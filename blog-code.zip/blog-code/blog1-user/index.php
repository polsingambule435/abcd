<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blog</title>
</head>
<body>
    <h1>Blog Posts</h1>
    <?php if (!empty($posts)) : ?>
        <ul>
            <?php foreach ($posts as $post) : ?>
                <li>
                    <a href="<?php echo base_url('blog/details/' . $post->id); ?>"><?php echo $post->title; ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else : ?>
        <p>No posts available.</p>
    <?php endif; ?>
</body>
</html>
