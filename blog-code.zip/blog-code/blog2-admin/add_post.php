<!-- views/admin/add_post.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Post</title>
</head>
<body>
    <h1>Add New Post</h1>
    <form action="<?php echo base_url('admin/save_post'); ?>" method="post">
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title"><br>
        
        <label for="content">Content:</label><br>
        <textarea id="content" name="content"></textarea><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>
