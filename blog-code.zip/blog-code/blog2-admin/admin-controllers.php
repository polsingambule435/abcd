// application/controllers/Admin.php
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load necessary models or libraries here
    }

    public function add_post() {
        $this->load->view('admin/add_post');
    }

    public function save_post() {
        $data = array(
            'title' => $this->input->post('title'),
            'content' => $this->input->post('content'),
            'created_at' => date('Y-m-d H:i:s')
        );

        // Save data to the database (replace 'posts' with your actual table name)
        $this->db->insert('posts', $data);

        // Redirect to a confirmation page or wherever you want
        redirect('admin/add_post');
    }
}
