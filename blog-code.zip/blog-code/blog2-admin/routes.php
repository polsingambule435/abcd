// application/config/routes.php
$route['admin/add_post'] = 'admin/add_post';
$route['admin/save_post'] = 'admin/save_post';
